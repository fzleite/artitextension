/**
 * Objeto para fazer leitura de JSON
 * @author Fernando Zimmermann Leite
 * @date 10/04/2018
 * {
 *     url : "",
 *     mimeType : ["application/json"],
 *     method : ["GET", "PUT", "PUSH"],
 *     format : ["object", "text"],
 *     auth : {
 *        user : "",    
 *        password : "",    
 *     }
 * }
 * 
 * Uso do prototype para adicionar novos metodos
 * get
 */
function WebService( args ) {
    this.wsParams = args;

    // Verifica parametro do objeto de entrada
    this.wsParams.mimeType = 
        ( isNaN(this.wsParams.mimeType) ? 
            "application/json" : 
            this.wsParams.mimeType
        );
    this.wsParams.method = 
        ( isNaN(this.wsParams.method) ? 
            "GET" : 
            this.wsParams.method 
        );
    this.wsParams.format = 
        ( isNaN(this.wsParams.format) ? 
            "object" : 
            this.wsParams.format 
        );
     this.wsParams.format = 
        ( ( this.wsParams.format !== "object" && this.wsParams.format !== "text" ) ? 
            "object" : 
            this.wsParams.format 
        );

    this.wsParams.auth.user = 
        ( !isNaN(this.wsParams.auth.user) ?
                this.wsParams.auth.user :
                null
        );
    this.wsParams.auth.password = 
        ( isNaN(this.wsParams.auth.password) ? 
            "" : 
            this.wsParams.auth.password 
        );
    this.wsParams.auth = 
        ( !isNaN(this.wsParams.auth) ?
            this.wsParams.auth :
            ( ( this.wsParams.auth.user != null ) ?
                this.wsParams.auth :
                null
            )
        );

    
    /**
     * Define metodo GET
     * @param callback
     */
    this.get = function(callback, errorCb){
        try{
            let format = this.wsParams.format;
            let wsResponse = new XMLHttpRequest();
            wsResponse.overrideMimeType( 
                this.wsParams.mimeType );
            if( this.wsParams.auth === null ){
                wsResponse.open( 
                    this.wsParams.method, 
                    this.wsParams.url, 
                    true
                );
            }else{
                wsResponse.open( 
                    this.wsParams.method, 
                    this.wsParams.url, 
                    true,
                    this.wsParams.user, 
                    this.wsParams.password
                );
            }
            wsResponse.onreadystatechange = function() {
                if( wsResponse.status === 403 ){
                    throw new Error( "WebService Error reading: Status 403: Forbidden" );
                }else if( wsResponse.status === 404 ){
                    throw new Error( "WebService Error reading: Status 404: Not Found" );
                }else if (wsResponse.readyState == 4 && wsResponse.status == "200") {
                    if( callback !== 'undefined' ){
                        if( typeof callback === 'function' ){
                            if( format === "object" )
                                callback( JSON.parse( wsResponse.responseText ) );
                            else
                                callback( wsResponse.responseText );
                        }
                    }
                }
            }
            wsResponse.send(null);
            errorCb = null;
        }catch(err){
            errorCb( err );
        }
    } // Fim do metodo getData
    
}